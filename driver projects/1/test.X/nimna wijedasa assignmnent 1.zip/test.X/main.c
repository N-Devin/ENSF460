/*
 * File:   main.c
 * Author: nimna
 *
 * Created on September 14, 2023, 9:46 AM
 */


#include "xc.h"

int main(void) 
{
    TRISAbits.TRISA0 = 1; // sets RAO as input
    TRISAbits.TRISA1 = 1; // sets RA1 as input
    TRISAbits.TRISA4 = 1; // sets RA4 as input
    TRISAbits.TRISA5 = 1; // sets RA5 as input
    
    TRISBbits.TRISB0 = 0; // sets RB0 as output
    TRISBbits.TRISB1 = 0; // sets RB1 as output
    TRISBbits.TRISB2 = 0; // sets RB2 as output
    TRISBbits.TRISB4 = 0; // sets RB4 as output
    TRISBbits.TRISB7 = 0; // sets RB7 as output
    TRISBbits.TRISB8 = 0; // sets RB8 as output
    TRISBbits.TRISB9 = 0; // sets RB9 as output
    TRISBbits.TRISB12 = 0; // sets RB12 as output
    TRISBbits.TRISB13 = 0; // sets RB13 as output
    
   
    while(1)
    {
        if ((PORTAbits.RA0 == 0) && (PORTAbits.RA1 == 0) && 
                (PORTAbits.RA4 == 0) && (PORTAbits.RA5 == 0))
        {
            LATB = 0x0000; // 0
        }
        else if ((PORTAbits.RA0 == 0) && (PORTAbits.RA1 == 0) && 
                (PORTAbits.RA4 == 0) && (PORTAbits.RA5 == 1))
        {
            LATB = 0x000f; // 3
        }
        else if ((PORTAbits.RA0 == 0) && (PORTAbits.RA1 == 0) 
                && (PORTAbits.RA4 == 1) && (PORTAbits.RA5 == 0))
        {
            LATB = 0x0000; // 0
        }
        else if ((PORTAbits.RA0 == 0) && (PORTAbits.RA1 == 0) 
                && (PORTAbits.RA4 == 1) && (PORTAbits.RA5 == 1))
        {
            LATB = 0x0001; //1
        }
        else if ((PORTAbits.RA0 == 0) && (PORTAbits.RA1 == 1) 
                && (PORTAbits.RA4 == 0) && (PORTAbits.RA5 == 0))
        {
            LATB = 0x005f; //4
        }
        else if ((PORTAbits.RA0 == 0) && (PORTAbits.RA1 == 1) 
                && (PORTAbits.RA4 == 0) && (PORTAbits.RA5 == 1))
        {
            LATB = 0x01ff; //6
        }
        else if ((PORTAbits.RA0 == 0) && (PORTAbits.RA1 == 1) 
                && (PORTAbits.RA4 == 1) && (PORTAbits.RA5 == 0))
        {
            LATB = 0x0000; // 0
        }
        else if ((PORTAbits.RA0 == 0) && (PORTAbits.RA1 == 1) 
                && (PORTAbits.RA4 == 1) && (PORTAbits.RA5 == 1))
        {
            LATB = 0x004f; //4
        }
        else if ((PORTAbits.RA0 == 1) && (PORTAbits.RA1 == 0) 
                && (PORTAbits.RA4 == 0) && (PORTAbits.RA5 == 0))
        {
            LATB = 0x0003; // 2
        }
        else
        {
            LATB = 0x0000;
            
        }
    }
}
